<?php
session_start();
?>
<!DOCTYPE html>
<html lang="fr">

<head>

	<meta charset="utf-8">
	<meta name="description" content="Site JMovies"/>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<?php
		include('./Rest/fonction_rest.php');
	?>
    <header>
        <h1>JMovies</h1>
		<?php
			echo'<p>';
			echo'Hello '.$_SESSION['userName'].'';
			echo' your id is '.$_SESSION['user_id'].'';
			echo'</p>';
		?>
    </header>
	<div id ="link"><a href="./main_page.php">for adding a review or see your recommendations</a></div>
	<?php
	if(!isset($_POST['user_id_consult']) || $_POST['user_id_consult'] == ""){
		echo '<h2>Consult review of a user with is id</h2>';
		echo'<div class ="inscription">';
			echo'<div>';
				echo'<form method= "POST" action="">';
					echo'<input type="number" name="user_id_consult" id="user_id_consult" min = "1000" max = "30000" placeholder="user Id">';
					echo'</br>';
					echo'<input type="submit" value="Consult all reviews"/>';
				echo'</form>';
			echo'</div>';
		echo'</div>';
		echo '<p class ="error">field for the reviews not or incorrectly filled</p>';
	}
	else{
		getAllReview($_POST['user_id_consult']);
	}
	?>
	<?php
	if(!isset($_POST['user_id_consult_best']) || $_POST['user_id_consult_best'] == ""){
		echo '<h2>Consult the best review of a user with is id</h2>';
		echo'<div class ="inscription">';
			echo'<div>';
				echo'<form method= "POST" action="">';
					echo'<input type="number" name="user_id_consult_best" id="user_id_consult_best" min = "1000" max = "30000" placeholder="user Id">';
					echo'</br>';
					echo'<input type="submit" value="Consult best reviews"/>';
				echo'</form>';
			echo'</div>';
		echo'</div>';
		echo '<p class ="error">field for the best reviews not or incorrectly filled</p>';
	}
	else{
		getBestReview($_POST['user_id_consult_best']);
	}
	?>
	<?php
	if(!isset($_POST['user_id_consult_worst']) || $_POST['user_id_consult_worst'] == ""){
		echo '<h2>Consult the best review of a user with is id</h2>';
		echo'<div class ="inscription">';
			echo'<div>';
				echo'<form method= "POST" action="">';
					echo'<input type="number" name="user_id_consult_worst" id="user_id_consult_worst" min = "1000" max = "30000" placeholder="user Id">';
					echo'</br>';
					echo'<input type="submit" value="Consult worst reviews"/>';
				echo'</form>';
			echo'</div>';
		echo'</div>';
		echo '<p class ="error">field for the worst reviews not or incorrectly filled</p>';
	}
	else{
		getWorstReview($_POST['user_id_consult_worst']);
	}
	?>
	<?php
	echo'<div id ="table_div">';
	echo '<h2>List of users</h2>';
		getAllUser();
	echo'</div>';
	?>
<footer>JMovies</footer>
</body>
</html>